// Empty root build; plugins managed per-module
buildscript {
    repositories {
        google()
        mavenCentral()
    }
    dependencies { }
}
allprojects {
    repositories {
        google()
        mavenCentral()
    }
}
